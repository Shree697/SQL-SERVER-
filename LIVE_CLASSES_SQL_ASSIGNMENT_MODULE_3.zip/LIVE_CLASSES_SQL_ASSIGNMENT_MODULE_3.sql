/********Create an �Orders� table which comprises of these columns � �order_id�, �order_date�, �amount�, �customer_id�****/
CREATE TABLE Orders 
(
order_id varchar(30),
order_date date,
amount float,
customer_id varchar(30)
)

SELECT * FROM orders

--value insertion in orders table
INSERT INTO Orders (order_id, order_date,amount,customer_id) VALUES
('001','2020-07-13',1298.98,'C0001'),
('0012','2020-05-02',1000.09,'C0003'),
('003','2020-07-07',275.25,'C0002');

/****** Make an inner join on �Customer� & �Order� tables on the �customer_id� column*****/
SELECT * FROM customer_table a
JOIN orders b ON a.customer_id = b.customer_id


/***** Make left and right joins on �Customer� & �Order� tables on the �customer_id� column*****/
SELECT * FROM customer_table a
LEFT JOIN orders b ON a.customer_id = b.customer_id;

SELECT * FROM customer_table a
RIGHT JOIN orders b ON a.customer_id = b.customer_id;

/*****Update the �Orders� table, set the amount to be 100 where �customer_id� is 3****/
UPDATE Orders SET amount = 100 
WHERE customer_id ='C0003'

SELECT * FROM orders
