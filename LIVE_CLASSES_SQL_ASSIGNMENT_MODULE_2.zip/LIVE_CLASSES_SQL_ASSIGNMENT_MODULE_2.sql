/*** Create a customer table which comprises of these columns � 
'customer_id', 'first_name', 'last_name', 'email', 'address', 'city','state','zip'**/
CREATE TABLE customer_table (
customer_id varchar(20) PRIMARY KEY,
first_name varchar(70) NOT NULL,
last_name varchar(70),
email varchar(100),
address varchar(200),
city varchar(30),
state varchar(30),
zip int);

SELECT * FROM customer_table

/*****Insert 5 new records into the table*****/
INSERT INTO customer_table (customer_id, first_name, last_name, email, address, city, state, zip)
VALUES ('C0001', 'Annie', 'Green', 'annie.green@gmail.com', '5th avenue, Sarson Lane', 'San Jose', 'California', 95112),
('C0034', 'Garret', 'Parker', 'garret.parker@yahoo.com', '17th cross lane', 'San Jose', 'California', 95112),
('C0012', 'Thomas', 'Fernandes', 'thomas.fernandes@gmail.com', '4th Lakeview lane', 'Chicago', 'Illinois', 60007),
('C0002', 'Mark', 'Tiller', 'mark.tiller@outlook.com', '2nd Avenue, Jordan Lane', 'Houston', 'Texas', 77001),
('C0003', 'Samantha', 'Vores', 'samantha.vores@yahoo.com', 'Simon Square, 125th Alley', 'San Diego', 'California', 91911);


SELECT * FROM customer_table;

/*****Select only the �first_name� & �last_name� columns from the customer table****/
SELECT first_name, last_name
FROM customer_table;

/******Select those records where �first_name� starts with �G� and city is �San Jose�*****/
SELECT * FROM customer_table
WHERE first_name LIKE 'G%' AND city = 'San Jose';




