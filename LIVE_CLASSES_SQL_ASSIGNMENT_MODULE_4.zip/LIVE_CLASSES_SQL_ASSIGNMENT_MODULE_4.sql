/*****Use the inbuilt functions and find the minimum, maximum and average amount from the orders table******/
SELECT MIN(amount) AS MIN_ORDER_AMOUNT, MAX(amount) AS MAX_ORDER_AMOUNT, AVG(amount) AS AVG_ORDER_AMOUNT
FROM Orders;

/**** Create a user-defined function, which will multiply the given number with 10********/
CREATE FUNCTION product_by_10 (@x int)
RETURNS int
AS
BEGIN
RETURN @x*10
END

SELECT dbo.product_by_10(9) AS Product_by_10

/*******Use the case statement to check if 100 is less than 200, greater than 200 or equal to 200 and print the corresponding value*****/

SELECT 
    CASE 
        WHEN 100 < 200 THEN '100 is less than 200'
        WHEN 100 > 200 THEN '100 is greater than 200'
        ELSE '100 is equal to 200'
    END AS OUTPUT;








