/****Employee Table creation****/
CREATE TABLE Tbl_employee(
employee_id int PRIMARY KEY,
First_name varchar(30),
Last_name varchar(30),
salary float,
joining_date datetime DEFAULT GETDATE(),
Department varchar(20))
=====================================
/****VALUE INSERTION IN EMPLOYEE TABLE***/
INSERT INTO tbl_employee values
(1,'Anika','Arora',100000,'2020-02-14 9:00:00','HR');
INSERT INTO tbl_employee values
(2,'Veena','Verma',80000,'2011-06-15 9:00:00','Admin'),
(3,'Vishal','Singhal',300000,'2020-02-16 9:00:00','HR'),
(4,'Sushanth','Singh',500000,'2020-02-17 9:00:00','Admin'),
(5,'Bhupal','Bhati',500000,'2011-06-18 9:00:00','Admin'),
(6,'Dheeraj','Diwan',200000,'2011-06-19 9:00:00','Account'),
(7,'Karan','Kumar',75000,'2020-01-14 9:00:00','Account'),
(8,'Chandrika','Chauhan',90000,'2011-04-15 9:00:00','Admin');

SELECT * FROM tbl_employee;
==================================================
/**********Employee Bonus Table*******/
CREATE TABLE Employee_bonus (
Employee_ref_id int FOREIGN KEY REFERENCES tbl_employee(employee_id),
Bonus_amount float,
bonus_date datetime)
=================================================
/******VALUE INSERTION IN EMPLOYEE BONUS TABLE*******/
INSERT INTO employee_bonus VALUES
(1,5000,'2020-02-16 0:00:00'),
(2,3000,'2011-06-16 0:00:00'),
(3,4000,'2020-02-16 0:00:00'),
(1,4500,'2020-02-16 0:00:00'),
(2,3500,'2011-06-16 0:00:00');

SELECT * FROM Employee_bonus
======================================================
/******EMPLOYEE TITLE TABLE********/
CREATE TABLE Employee_title (
Employee_ref_id int,
Employee_title varchar(30),
affective_date datetime);
=========================================================
/*******VALUE INSERTION IN EMPLOYEE TITLE TABLE****/
INSERT INTO employee_title VALUES
(1,'Manager','2016-02-20'),
(2,'Executive','2016-06-11'),
(8,'Executive','2016-06-11'),
(5,'Manager','2016-06-11'),
(4,'Asst. Manager','2016-06-11'),
(7,'Executive','2016-06-11'),
(6,'Lead','2016-06-11'),
(3,'Lead','2016-06-11');

SELECT * FROM Employee_title
======================================================
/*****TASK to be performed******/
-- Display the �FIRST_NAME� from Employee table using the alias name as Employee_name
SELECT first_name AS Employee_name
FROM tbl_employee

-- Display �LAST_NAME� from Employee table in upper case
SELECT UPPER(last_name) AS LAST_NAME
FROM tbl_employee

-- Display unique values of DEPARTMENT from EMPLOYEE table.
SELECT DISTINCT Department
FROM tbl_employee

--Display the first three characters of LAST_NAME from EMPLOYEE table.
SELECT substring(last_name,1,3)
FROM tbl_employee

--Display the unique values of DEPARTMENT from EMPLOYEE table and prints its length.
SELECT DISTINCT Department, len(Department)
FROM tbl_employee
GROUP BY Department

--Display the FIRST_NAME and LAST_NAME from EMPLOYEE table into a single column AS FULL_NAME.
SELECT Concat(First_name,' ',last_name) AS FULL_NAME 
FROM tbl_employee

--DISPLAY all EMPLOYEE details from the employee table order by FIRST_NAME Ascending.
SELECT * FROM tbl_employee
ORDER BY first_name

--Display all EMPLOYEE details order by FIRST_NAME Ascending and DEPARTMENT Descending.
SELECT * FROM tbl_employee
ORDER BY first_name, Department DESC

--Display details for EMPLOYEE with the first name as �VEENA� and �KARAN� from EMPLOYEE table.
SELECT * FROM tbl_employee
WHERE first_name IN ('Veena','Karan')

--Display details of EMPLOYEE with DEPARTMENT name as �Admin�.
SELECT * FROM tbl_employee
WHERE department='Admin'

--DISPLAY details of the EMPLOYEES whose FIRST_NAME contains �V
SELECT * FROm tbl_employee
WHERE first_name LIKE '%v%'

--DISPLAY details of the EMPLOYEES whose SALARY lies between 100000 and 500000
SELECT * FROM tbl_employee
WHERE salary BETWEEN 100000 AND 500000

-- Display details of the employees who have joined in Feb-2020.
SELECT * FROM tbl_employee
WHERE month(joining_date)='02' AND year(joining_date)='2020'

--Display employee names with salaries >= 50000 and <= 100000
SELECT concat(first_name,' ',last_name) AS Employee_name
FROM tbl_employee
WHERE salary >=50000 AND salary <=100000

--DISPLAY details of the EMPLOYEES who are also Managers.
SELECT * FROM tbl_employee a
INNER JOIN employee_title b ON a.employee_id = b.employee_ref_id
WHERE b.employee_title = 'Manager'

--DISPLAY duplicate records having matching data in some fields of a table.
SELECT Department, Count(*) AS Duplicates
FROM tbl_employee
GROUP BY Department
HAVING Count(*)>1

SELECT employee_title, count(*) AS Duplicates
FROM employee_title 
GROUP BY employee_title
HAVING count(*)>1

--Display only odd rows from a table.
SELECT * FROM tbl_employee
WHERE employee_id%2<>0

--Clone a new table from EMPLOYEE table.
SELECT * INTO clone_employee_tbl
FROM tbl_employee

SELECT * FROM clone_employee_tbl

-- DISPLAY the TOP 2 highest salary from a table.
SELECT DISTINCT TOP 2 salary FROM tbl_employee
ORDER BY Salary DESC

--DISPLAY the list of employees with the same salary.
SELECT DISTINCT a.first_name AS Employees_same_salary, a.salary
FROM tbl_employee a, tbl_employee b
WHERE a.employee_id <> b.employee_id AND a.salary = b.salary
GROUP BY a.salary,a.first_name

--Display the second highest salary from a table
SELECT salary 
FROM (SELECT *,DENSE_RANK() OVER(ORDER BY salary DESC) AS RANKING
	  FROM tbl_employee) A
WHERE RANKING = 2

--Display the first 50% records from a table.
SELECT TOP 50 PERCENT * FROM tbl_employee;

--Display the departments that have less than 4 people in it.
SELECT Department, COUNT(*) AS No_of_employees
FROM tbl_employee
GROUP BY Department
HAVING COUNT(*)<4;

--Display all departments along with the number of people in there.
SELECT Department, COUNT(*) AS No_of_employees
FROM tbl_employee
GROUP BY Department;

--Display the name of employees having the highest salary in each department. 
SELECT Department, MAX(salary) AS Highest_salary
FROM tbl_employee
GROUP BY Department; 

--Display the names of employees who earn the highest salary.
SELECT CONCAT(First_name,' ',Last_name) AS Emp_name 
FROM Tbl_employee 
WHERE salary= (SELECT MAX(salary) FROM Tbl_employee);

--Display the average salaries for each department
SELECT Department, AVG(Salary) AS Avg_salary
FROM tbl_employee
GROUP BY Department;

--29 display the name of the employee who has got maximum bonus
WITH CTE1 AS (SELECT CONCAT(First_name,' ',Last_name) AS Emp_name,Bonus_amount 
 FROM Employee_bonus a
 JOIN tbl_employee b ON a.employee_ref_id = b.employee_id)

SELECT Emp_name FROM CTE1
WHERE Bonus_amount=(SELECT MAX(Bonus_amount) FROM CTE1);

--Display the first name and title of all the employees
SELECT First_name, Last_name AS Title
FROM Tbl_employee;

